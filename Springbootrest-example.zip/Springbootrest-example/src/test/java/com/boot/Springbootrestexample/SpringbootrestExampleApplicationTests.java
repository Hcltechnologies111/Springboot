package com.boot.Springbootrestexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootrestExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
