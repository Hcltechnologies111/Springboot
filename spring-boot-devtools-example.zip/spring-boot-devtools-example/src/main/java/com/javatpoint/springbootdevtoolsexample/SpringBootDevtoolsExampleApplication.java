package com.javatpoint.springbootdevtoolsexample;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class SpringBootDevtoolsExampleApplication 
{
public static void main(String[] args) 
{
SpringApplication.run(SpringBootDevtoolsExampleApplication.class, args);
}
}